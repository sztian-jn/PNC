gmx grompp -f em_1.mdp -c gromacs.gro -o em_1.tpr -p gromacs.top -r gromacs.gro -n index.ndx -maxwarn 2 
gmx mdrun -deffnm em_1 -v 

gmx grompp -f em_2.mdp -c em_1.gro -o em_2.tpr -p gromacs.top -r em_1.gro -n index.ndx -maxwarn 2
gmx mdrun -deffnm em_2 -v

gmx grompp -f em_3.mdp -c em_2.gro -o em_3.tpr -p gromacs  -n index.ndx 
gmx mdrun -deffnm em_3 -v

gmx grompp -f nvt.mdp -c em_3.gro -o nvt.tpr -p gromacs.top -r em_3.gro -n index.ndx -maxwarn 2
gmx mdrun -deffnm nvt -v -ntmpi 1  -gpu_id 0

gmx grompp -f nvt2.mdp -c nvt.gro -o nvt2.tpr -p gromacs.top  -n index.ndx -t nvt.cpt
gmx mdrun -deffnm nvt2 -v -ntmpi 1

gmx grompp -f npt.mdp -c nvt2.gro -o npt.tpr -p gromacs.top -n index.ndx -t nvt2.cpt
gmx mdrun -deffnm npt -v -ntmpi 1

gmx grompp -f md.mdp -c npt.gro -o md.tpr -p gromacs.top -n index.ndx -t npt.cpt -maxwarn 2
gmx mdrun -deffnm md -v -ntmpi 1 -plumed plumed.dat
